import java.sql.Date;
import java.text.SimpleDateFormat;

public class test {

  public static void main(String[] args) {
    // TODO Auto-generated method stub
//    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
//    Date date = new Date(System.currentTimeMillis());
//    System.out.println(formatter.format(date));

    Date date = new Date(System.currentTimeMillis());
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String time = formatter.format(date);
    System.out.println(time);

  }

}
