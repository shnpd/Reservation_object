package servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import factory.DaoFactory;

/**
 * Servlet implementation class menu_Servlet
 */
//@WebServlet("/menu_Servlet")
public class menu_Servlet extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public menu_Servlet() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setCharacterEncoding("UTF-8");
    request.setCharacterEncoding("UTF-8");
    response.setContentType("text/html;charset=utf-8");

    PrintWriter out = response.getWriter();
    String acttypeString = request.getParameter("type");
    String add_dish_nameString = request.getParameter("dishname");
    // 增加菜品
    if ("add_dish".equals(acttypeString)) {

      // 当前不存在该菜品
      try {
        if (!DaoFactory.getDishDaoInstance().search(add_dish_nameString).next()) {

          float add_dish_priceString = Float.parseFloat(request.getParameter("dishprice"));
          // 待改权限 regist的执行有问题
          if (DaoFactory.getDishDaoInstance().AddMenu(add_dish_nameString, add_dish_priceString)) {
            // 修改成功
            out.println("<script>alert('添菜成功!');window.location.href='menu_info.jsp'</script>");
          } else {
            // 修改失败
            out.println("<script>alert('添菜失败!');window.location.href='menu_info.jsp'</script>");
          }
        } else {
          // 不存在该用户
          out.println("<script>alert('当前已有该菜品,请不要加入重名菜品!');window.location.href='menu_info.jsp'</script>");
        }
      } catch (NumberFormatException | SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
    if ("update_price".equals(acttypeString)) {
      float add_dish_priceString = Float.parseFloat(request.getParameter("dishprice"));
      if (DaoFactory.getDishDaoInstance().Update_price(add_dish_nameString, add_dish_priceString)) {
        // 修改成功
        out.println("<script>alert('修改菜品价格成功!');window.location.href='menu_info.jsp'</script>");
      } else {
        // 修改失败
        out.println("<script>alert('修改菜品价格失败!');window.location.href='menu_info.jsp'</script>");
      }
    }
    if ("delete".equals(acttypeString)) {
      // 有该菜品
      if (DaoFactory.getDishDaoInstance().search(add_dish_nameString) != null) {
        // 待改权限 regist的执行有问题
        if (DaoFactory.getDishDaoInstance().delete(add_dish_nameString)) {
          // 修改成功
          out.println("<script>alert('删除菜品成功!');window.location.href='menu_info.jsp'</script>");

        } else {
          // 修改失败
          out.println("<script>alert('删除菜品失败!');window.location.href='menu_info.jsp'</script>");
        }
      } else {
        // 不存在该用户
        out.println("<script>alert('无该菜品或已被删除,请重新选择菜品删除!');window.location.href='menu_info.jsp'</script>");
      }
    } else {
      out.println("啥也不是");
    }

  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}
