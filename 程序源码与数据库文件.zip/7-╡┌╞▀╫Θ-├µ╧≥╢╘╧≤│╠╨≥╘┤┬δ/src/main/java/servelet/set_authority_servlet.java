package servelet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import factory.DaoFactory;

/**
 * Servlet implementation class set_authority_servlet
 */
//@WebServlet("/set_authority_servlet")
public class set_authority_servlet extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public set_authority_servlet() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
    response.setCharacterEncoding("UTF-8");
    request.setCharacterEncoding("UTF-8");
    response.setContentType("text/html;charset=utf-8");

    PrintWriter out = response.getWriter();
    String acttypeString = request.getParameter("type");
    String usernameString = request.getParameter("username");
    String authorityString = request.getParameter("aim_authority");
    // out.println("asujkhksadfj");
    // out.println(usernameString);
    if ("update".equals(acttypeString)) {
      // 当前存在该用户
      if (DaoFactory.getUserDaoInstance().if_exist(usernameString)) {
        // 待改权限 regist的执行有问题
        if (DaoFactory.getUserDaoInstance().update_authority(usernameString, authorityString) == true) {
          // 修改成功
          // out.println("权限修改成功!");
          out.println("<script>alert('权限修改成功!');window.location.href='set_authority.jsp'</script>");
        } else {
          // 修改失败
          // out.println("权限修改失败!");
          out.println("<script>alert('权限修改失败!');window.location.href='set_authority.jsp'</script>");
        }
      } else {
        // 不存在该用户
        // out.println(usernameString);
        // out.println("无该用户!");
        out.println("<script>alert('无该用户!');window.location.href='set_authority.jsp'</script>");
      }
    }
    if ("delete".equals(acttypeString)) {
      if (DaoFactory.getUserDaoInstance().if_exist(usernameString)) {
        // 待改权限 regist的执行有问题
        if (DaoFactory.getUserDaoInstance().delete(usernameString) == true) {
          // 修改成功
          out.println("<script>alert('删除成功!');window.location.href='set_authority.jsp'</script>");
        } else {
          // 修改失败
          out.println("<script>alert('删除失败!');window.location.href='set_authority.jsp'</script>");
          // out.println("删除失败!");
          // out.println("<script>window.location.href='set_authority.jsp'</script>");
        }
      } else {
        // 不存在该用户
        out.println("<script>alert('不存在该用户!');window.location.href='set_authority.jsp'</script>");
      }
    }

  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}
