package servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.user;
import factory.DaoFactory;

/**
 * Servlet implementation class loging_servlet
 */
//@WebServlet("/loging_servlet")
public class loging_servlet extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public loging_servlet() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */

  // 是否存在该用户
  private boolean if_exist(String username, String pwd, String authority) {
    List<user> list = new ArrayList<user>();
    try {
      list = DaoFactory.getUserDaoInstance().getUsers();
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    user bean = new user();
    for (int i = 0; i < list.size(); i++) {
      bean = list.get(i);
      if (bean.getAccount().equals(username) && bean.getPwd().equals(pwd) && bean.getType().equals(authority)) {
        return true;
      }

    }
    return false;
  }

  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
    response.setCharacterEncoding("UTF-8");
    request.setCharacterEncoding("UTF-8");
    response.setContentType("text/html;charset=utf-8");

    PrintWriter out = response.getWriter();

    String username = request.getParameter("username");
    String pwd = request.getParameter("password");
    String user_authority = request.getParameter("type").toString();

    if (if_exist(username, pwd, user_authority) == true) {

      request.getSession().setAttribute("authority", user_authority);// 权限
      if ("商家".equals(user_authority) == true) {
        // 商家页面
        request.getSession().setAttribute("username", username);// 用户名
        out.println("<script>alert('登陆成功!');window.location.href='./admin/menu_info.jsp'</script>");
      } else {
        if ("厨师".equals(user_authority) == true) {
          request.getSession().setAttribute("chefname", username);// 用户名
          out.println("<script>alert('登陆成功!');window.location.href='./chef/showorder.jsp'</script>");

        } else {
          if ("顾客".equals(user_authority) == true) {
            request.getSession().setAttribute("custname", username);// 用户名
            out.println("<script>alert('登陆成功!');window.location.href='./user/Showmenu.jsp'</script>");
          } else {
            out.println("<script>alert('4');</script>");
          }
        }
      }
    } else {

      out.println("<script>alert('用户名或密码错误,请重新登陆!');window.location.href='./loging.jsp'</script>");
    }

  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}
