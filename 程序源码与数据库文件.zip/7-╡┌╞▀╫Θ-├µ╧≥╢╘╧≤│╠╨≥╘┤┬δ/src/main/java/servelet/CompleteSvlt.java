package servelet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.pay;
import dao.IOrderDao;
import dao.IPayDao;
import factory.DaoFactory;

/**
 * Servlet implementation class completeSvlt
 */
@WebServlet("/CompleteSvlt")
public class CompleteSvlt extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public CompleteSvlt() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
    request.setCharacterEncoding("utf-8");
    response.setCharacterEncoding("utf-8");
    response.setContentType("text/html;charset=utf-8");
    String no = request.getParameter("no");
    String name = request.getParameter("name");
    String time = request.getParameter("time");
    String amount = request.getParameter("amount");
    String account = request.getParameter("account");
    IOrderDao iod = DaoFactory.getOrderDaoInstance();
    Boolean flag = iod.complete(no);
    PrintWriter out = response.getWriter();
    IPayDao ipd = DaoFactory.getPayDaoInstance();
    pay addPay = new pay();
    addPay.setNumber(Integer.parseInt(no));
    addPay.setAccount(account);
    addPay.setDish(name);
    addPay.setAmount(Integer.parseInt(amount));
    addPay.setTime(time);
    boolean flag2 = ipd.add(addPay);

    if (flag && flag2) {
      out.println("<script>alert('�ϲ˳ɹ���');location.href='chef/showorder.jsp'</script>");
    } else {
      out.println("<script>alert('�ϲ�ʧ�ܣ������ԣ�');location.href='chef/showorder.jsp'</script>");
    }
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}
