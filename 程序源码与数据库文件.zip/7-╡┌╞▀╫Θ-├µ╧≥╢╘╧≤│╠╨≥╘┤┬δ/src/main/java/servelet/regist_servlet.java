package servelet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.user;
import factory.DaoFactory;

/**
 * Servlet implementation class regist_servlet
 */
//@WebServlet("/regist_servlet")
public class regist_servlet extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public regist_servlet() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
    // response.getWriter().append("Served at: ").append(request.getContextPath());
    response.setCharacterEncoding("UTF-8");
    request.setCharacterEncoding("UTF-8");
    response.setContentType("text/html;charset=utf-8");

    PrintWriter out = response.getWriter();

    String username = request.getParameter("username");
    String pwd = request.getParameter("password");
    String user_authority = request.getParameter("type");

    if (DaoFactory.getUserDaoInstance().if_exist(username))// 已经有该用户
    {
      out.println("<script>alert('该用户名已存在,请重新注册!');window.location.href='regist.jsp'</script>");
    } else {
      // 当前不存在该菜品
      user new_one = new user();
      new_one.setAccount(username);
      new_one.setPwd(pwd);
      new_one.setType(user_authority);
      if (DaoFactory.getUserDaoInstance().resgist(new_one)) {
        out.println("<script>alert('注册成功!将返回登陆界面!');window.location.href='loging.jsp'</script>");
      } else {
        out.println("<script>alert('注册失败!请重新尝试!');window.location.href='regist.jsp'</script>");
      }
    }
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}
