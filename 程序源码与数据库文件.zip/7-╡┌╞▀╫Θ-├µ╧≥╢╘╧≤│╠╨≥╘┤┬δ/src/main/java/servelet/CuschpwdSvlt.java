package servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.user;
import factory.DaoFactory;

/**
 * Servlet implementation class User_Servlet
 */
@WebServlet("/CuschpwdSvlt")
public class CuschpwdSvlt extends HttpServlet {
  private static final long serialVersionUID = 1L;

  /**
   * @see HttpServlet#HttpServlet()
   */
  public CuschpwdSvlt() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
    // response.getWriter().append("Served at: ").append(request.getContextPath());
    response.setCharacterEncoding("UTF-8");
    request.setCharacterEncoding("UTF-8");
    response.setContentType("text/html;charset=utf-8");

    PrintWriter out = response.getWriter();

    String username = (String) request.getSession().getAttribute("custname");
    String old_pwd = request.getParameter("old_pwd");
    String new_pwd = request.getParameter("new_pwd");
    String renew_pwd = request.getParameter("renew_pwd");
    List<user> list = new ArrayList<user>();
    try {
      list = DaoFactory.getUserDaoInstance().getUsers();
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    if (!new_pwd.equals(renew_pwd)) {
      out.println("<script>alert('两次密码输入不一致!');window.location.href='user/ChangePwd.jsp'</script>");
    } else {
      user bean = new user();
      boolean find_if = false;
      for (int i = 0; i < list.size(); i++) {
        bean = list.get(i);
        if (bean.getAccount().equals(username)) {
          // 存在该用户
          find_if = true;
          if (bean.getPwd().equals(old_pwd)) {
            // 旧密码正确
            if (DaoFactory.getUserDaoInstance().update_pwd(username, new_pwd) == true) {
              out.println("<script>alert('密码修改成功!');window.location.href='user/ChangePwd.jsp'</script>");
            } else {
              out.println("<script>alert('密码修改失败!');window.location.href='user/ChangePwd.jsp'</script>");
            }
          } else {// 旧密码错误
            out.println("<script>alert('旧密码验证错误!');window.location.href='user/ChangePwd.jsp'</script>");
          }
        }
      }
      if (!find_if) {
        out.println("<script>alert('请先登陆账号!');window.location.href='user/ChangePwd.jsp'</script>");
      }
    }
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
   *      response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}
