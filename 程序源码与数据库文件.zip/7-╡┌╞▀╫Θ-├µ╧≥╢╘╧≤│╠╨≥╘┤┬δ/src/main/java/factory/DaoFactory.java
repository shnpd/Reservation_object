package factory;

import dao.IDishDao;
import dao.IOrderDao;
import dao.IPayDao;
import dao.IUserDao;
import dao.impl.DishDaoImpl;
import dao.impl.OrderDaoImpl;
import dao.impl.PayDaoImpl;
import dao.impl.UserDaoImpl;

public class DaoFactory {

  public static IDishDao getDishDaoInstance() {
    return new DishDaoImpl();
  }

  public static IOrderDao getOrderDaoInstance() {
    return new OrderDaoImpl();
  }

  public static IUserDao getUserDaoInstance() {
    return new UserDaoImpl();
  }

  public static IPayDao getPayDaoInstance() {
    return new PayDaoImpl();
  }
}
