package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dao.IDishDao;
import util.DBCon;
import util.DbcpPool;
import util.Dbutil;

public class DishDaoImpl implements IDishDao {

  @Override
  public ResultSet search() {
    Connection con = DBCon.getConnection();
    String sql = "select * from menu";
    try {
      PreparedStatement ps = con.prepareStatement(sql);
      ResultSet rs = ps.executeQuery();
      return rs;
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return null;
  }

  public boolean Update_price(String dish_name, float dish_price) {
    String sql = "UPDATE  menu SET ordering_amount=? WHERE ordering_dishes=?";

    PreparedStatement ps = DbcpPool.executePreparedStatement(sql);
    int result = 0;
    try {
      ps.setFloat(1, dish_price);
      ps.setString(2, dish_name);
      result = ps.executeUpdate();
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    DbcpPool.close();

    if (result > 0)
      return true;
    else {
      return false;
    }
  }

  @Override
  public boolean delete(String dish_name) {
    /*
     * String sql = "DELETE FROM menu where ordering_dishes = '" + dish_name + "'";
     * int result = 0; result = DbcpPool.executeUpdate(sql); DbcpPool.close();
     * 
     * // DbcpPool.close(); // return result; if (result > 0) return true; else
     * return false;
     */

    Connection con = DBCon.getConnection();
    String sql = "Delete from menu where ordering_dishes=?";
    try {
      PreparedStatement ps = con.prepareStatement(sql);
      ps.setString(1, dish_name);
      int rs = ps.executeUpdate();
      if (rs != 0)
        return true;
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return false;

  }

  @Override
  public ResultSet search(String dish_name) {
    Connection con = DBCon.getConnection();
    String sql = "select * from menu where ordering_dishes=? ";
    try {
      PreparedStatement ps = con.prepareStatement(sql);
      ps.setString(1, dish_name);
      ResultSet rs = ps.executeQuery();
      return rs;
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return null;
  }

  @Override
  public boolean AddMenu(String name, float price) {
    Connection con = Dbutil.getConnection();
    String sql = "insert into menu values(?,?)";
//    String sql2 = "insert into menu values(" + name + "," + price + ")";
    try {
      PreparedStatement ps = con.prepareStatement(sql);
      ps.setString(1, name);
      ps.setFloat(2, price);
      int result = ps.executeUpdate();

      if (result > 0) {
//      DbcpPool.close();
        return true;
      }
    } catch (SQLException e) {
      // TODO: handle exception
      e.printStackTrace();
    }

    DbcpPool.close();
    return false;
  }

}
