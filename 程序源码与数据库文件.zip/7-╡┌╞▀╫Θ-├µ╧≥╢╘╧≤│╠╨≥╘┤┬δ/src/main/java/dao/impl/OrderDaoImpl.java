package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import dao.IOrderDao;
import util.DBCon;

public class OrderDaoImpl implements IOrderDao {

  /**
   * �˿��µ�����
   */
  @Override
  public boolean insert(String dish, float amount, float price, String remark, String account) {
    // TODO Auto-generated method stub
    Connection con = DBCon.getConnection();
    String sql = "insert into order_info values(?,?,?,?,?,?,?,?,?)";
    Date date = new Date(System.currentTimeMillis());
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String time = formatter.format(date);
    try {
      PreparedStatement ps = con.prepareStatement(sql);
      ps.setInt(1, 0);
      ps.setString(2, dish);
      ps.setString(3, time);
      ps.setFloat(4, amount);
      ps.setFloat(5, price);
      ps.setString(6, account);
      ps.setString(7, remark);
      ps.setString(8, "no");
      ps.setString(9, "no");
      int result = ps.executeUpdate();
      if (result == 1)
        return true;
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return false;
  }

  /**
   * �������ж�����Ϣ
   */
  @Override
  public ResultSet showAccount() {
    // TODO Auto-generated method stub
    Connection con = DBCon.getConnection();
    String sql = "select * from order_info where if_pay='no' ";
    try {
      PreparedStatement ps = con.prepareStatement(sql);
      ResultSet rs = ps.executeQuery();
      return rs;
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return null;
  }

  @Override
  public boolean complete(String no) {
    Connection con = DBCon.getConnection();
    int not = Integer.parseInt(no);
    String sql = "update order_info set if_complete='yes' where ordering_number=?";
    try {
      PreparedStatement ps = con.prepareStatement(sql);
      ps.setInt(1, not);
      int result = ps.executeUpdate();
      if (result != 0) {
        return true;
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return false;
  }

  @Override
  public ResultSet showChef() {
    // TODO Auto-generated method stub
    Connection con = DBCon.getConnection();
    String sql = "select * from order_info where if_pay='yes' and if_complete='no' ";
    try {
      PreparedStatement ps = con.prepareStatement(sql);
      ResultSet rs = ps.executeQuery();
      return rs;
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return null;
  }

  @Override
  public boolean delete(int no) {
    // TODO Auto-generated method stub
    Connection con = DBCon.getConnection();
    String sql = "Delete from order_info where ordering_number=?";
    try {
      PreparedStatement ps = con.prepareStatement(sql);
      ps.setInt(1, no);
      int rs = ps.executeUpdate();
      if (rs != 0)
        return true;
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return false;
  }

  @Override
  public boolean paybill(String account) {
    Connection con = DBCon.getConnection();
    String sql = "update order_info set if_pay=? where login_account=?";
    try {
      PreparedStatement ps = con.prepareStatement(sql);
      ps.setString(1, "yes");
      ps.setString(2, account);
      int result = ps.executeUpdate();
      if (result != 0) {
        return true;
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return false;
  }
}
