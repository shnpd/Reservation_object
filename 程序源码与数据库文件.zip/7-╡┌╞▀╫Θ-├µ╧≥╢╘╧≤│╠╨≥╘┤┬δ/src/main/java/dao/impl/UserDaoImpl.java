package dao.impl;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import util.Dbutil;
import bean.user;
import dao.IUserDao;
import util.DbcpPool;
public class UserDaoImpl implements IUserDao{

	@Override
	public boolean if_exist(String user_name) {
		ResultSet rs = null;
		String sql = "select * from account where login_account= '" + user_name + "'";
		rs = Dbutil.executeQuery(sql);
		try {
			if (rs != null && rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}

	@Override
	public boolean resgist(user user_message) {
		String sql = "insert into account(login_account,login_pwd,login_type) values(?,?,?)";
		int result = 0;
		PreparedStatement ps =DbcpPool.executePreparedStatement(sql);
		try {
			ps.setString(1, user_message.getAccount());
			ps.setString(2, user_message.getPwd());
			ps.setString(3, user_message.getType());
			result = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		DbcpPool.close();
		
		if (result > 0) {
			
			return true;
		} else {
			return false;
		}
	}
	
	@Override
	public boolean update_authority(String user_name, String authority) {
		String sql = "UPDATE account SET login_type=? WHERE login_account=?";

		PreparedStatement ps = DbcpPool.executePreparedStatement(sql);
		int result = 0;
		try {
			ps.setString(1, authority);
			ps.setString(2, user_name);
			result = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DbcpPool.close();
		
		if (result > 0)
			return true;
		else {
			return false;
		}
	}
	
	@Override
	public boolean update_pwd(String user_name, String pwd) {
		String sql = "UPDATE account SET login_pwd=? WHERE login_account=?";

		PreparedStatement ps = DbcpPool.executePreparedStatement(sql);
		int result = 0;
		try {
			ps.setString(1, pwd);
			ps.setString(2, user_name);
			result = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DbcpPool.close();
		
		if (result > 0)
			return true;
		else {
			return false;
		}
	}
	
	@Override
	public boolean update(String user_name, user user_message) {
		String sql = "UPDATE account SET login_account=?,login_pwd=?,login_type=? WHERE login_account=?";

		PreparedStatement ps = DbcpPool.executePreparedStatement(sql);
		int result = 0;
		try {
			ps.setString(1, user_message.getAccount());
			ps.setString(2, user_message.getPwd());
			ps.setString(3, user_message.getType());
			ps.setString(4, user_name);
			result = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DbcpPool.close();
		
		if (result > 0)
			return true;
		else {
			return false;
		}
	}

	@Override
	public boolean delete(String user_name) {
		String sql = "DELETE FROM account where login_account = '" + user_name + "'";
		int result = 0;
		result = DbcpPool.executeUpdate(sql);
		DbcpPool.close();
		
		// DbcpPool.close();
		// return result;
		if (result > 0)
			return true;
		else
			return false;
	}

	@Override
	public List<user> getUsers() throws SQLException {
		String sql = "select * from  account ";
		List<user> list = new ArrayList<user>();
		ResultSet rs = DbcpPool.executeQuery(sql);
		try {
			while (rs.next()) {
				user temp = new user();
				temp.setAccount(rs.getString("login_account"));
				temp.setPwd(rs.getString("login_pwd"));
				temp.setType(rs.getString("login_type"));
				list.add(temp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DbcpPool.close();
		return list;
	}

}
