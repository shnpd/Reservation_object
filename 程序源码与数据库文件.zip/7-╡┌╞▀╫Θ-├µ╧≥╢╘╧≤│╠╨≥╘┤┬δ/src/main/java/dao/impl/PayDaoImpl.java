package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.pay;
import dao.IPayDao;
import util.DBCon;
import util.DbcpPool;

public class PayDaoImpl implements IPayDao {

  @Override
  public boolean add(pay add_temp) {
    Connection con = DBCon.getConnection();
    String sql = "insert into pay_info values(?,?,?,?,?)";
    int result = 0;
    try {
      PreparedStatement ps = con.prepareStatement(sql);
      ps.setInt(1, 0);
      ps.setString(2, add_temp.getDish());
      ps.setString(3, add_temp.getTime());
      ps.setInt(4, add_temp.getAmount());
      ps.setString(5, add_temp.getAccount());
      result = ps.executeUpdate();
      if (result == 1)
        return true;
    } catch (SQLException e) {
      // TODO: handle exception
      e.printStackTrace();
    }
    return false;
  }

  @Override
  public boolean delete(String Pay_number) {
    String sql = "DELETE FROM pay_info where Pay_number = '" + Pay_number + "'";
    int result = 0;
    result = DbcpPool.executeUpdate(sql);
    DbcpPool.close();

    // DbcpPool.close();
    // return result;
    if (result > 0)
      return true;
    else
      return false;
  }

  @Override
  public List<pay> getPays() throws SQLException {
    String sql = "select * from  pay_info ";
    List<pay> list = new ArrayList<pay>();
    ResultSet rs = DbcpPool.executeQuery(sql);
    try {
      while (rs.next()) {
        pay temp = new pay();
        temp.setAccount(rs.getString("login_account"));
        temp.setDish(rs.getString("ordering_dishes"));
        temp.setNumber(rs.getInt("Pay_number"));
        temp.setAmount(rs.getInt("ordering_amount"));
        temp.setTime(rs.getString("ordering_time"));
        list.add(temp);
      }
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    DbcpPool.close();
    return list;
  }

}
