package dao;

import java.sql.ResultSet;

public interface IDishDao {

  /**
   * 
   * @return �˵�����
   */
  public ResultSet search();

  public boolean Update_price(String dish_name, float dish_price);

  public boolean delete(String dish_name);

  public ResultSet search(String dish_name);

  /**
   * 
   * @param name  ����
   * @param price �۸�
   */
  public boolean AddMenu(String name, float price);

}
