package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import bean.user;
public interface IUserDao {
	
	/*
	 * 是否存在该用户
	 * @param book_name:用户名
	 */
	public boolean if_exist(String user_name);

	 /*
	 * 注册用户信息
	 * @param user_message 要存储的用户信息书籍信息
	 * @return true:注册成功 false:注册失败
	 */
	public boolean resgist(user user_message);
	
	/*
	 * 修改用户状态
	 * @param user_name 要修改用户名的书的书名
	 * @param userk_message 修改后的用户状态
	 */
	public boolean update(String user_name, user user_message);
	
	/*
	 * 删除指定用户
	 * @param book_name 要删除的用户的名字
	 */
	public boolean delete(String user_name);
	
	public List<user> getUsers() throws SQLException;
	
	//修改目的用户的权限
	boolean update_authority(String user_name, String authority);

	boolean update_pwd(String user_name, String pwd);
}
