package dao;

import java.sql.SQLException;
import java.util.List;

import bean.pay;

public interface IPayDao {

  public boolean add(pay add_temp);

  public boolean delete(String Pay_number);

  public List<pay> getPays() throws SQLException;

}
