package util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;
import org.apache.tomcat.dbcp.dbcp2.BasicDataSourceFactory;

public class DbcpPool {
  /**
   * 澹版槑JDBC鐩稿叧瀵硅薄
   */
  protected static Statement s = null;
  protected static ResultSet rs = null;
  protected static Connection conn = null;
  private static BasicDataSource dataSource = null;

  // 鍒濆鍖栨暟鎹簱杩炴帴姹�
  public static void init() {
    if (dataSource != null) {
      try {
        dataSource.close();
      } catch (Exception e) {
        e.printStackTrace();
      }
      dataSource = null;
    }
    // 浣跨敤Properties瀵硅薄瀹氫箟鏁版嵁搴撹繛鎺ユ睜淇℃伅
    try {
      Properties p = new Properties();
      p.setProperty("driverClassName", "com.mysql.jdbc.Driver");
      p.setProperty("url", "jdbc:mysql://localhost:3306/order?useUnicode=true&characterEncoding=UTF-8");
      p.setProperty("username", "root");
      p.setProperty("password", "shn001221");
      p.setProperty("maxActive", "30");
      p.setProperty("maxIdle", "10");
      p.setProperty("maxWait", "1000");
      p.setProperty("removeAbandoned", "false");
      p.setProperty("removeAbandonedTimeout", "120");
      p.setProperty("testOnBorrow", "true");
      p.setProperty("logAbandoned", "true");
      // 浠ユ寚瀹氫俊鎭垱寤烘暟鎹簮
      dataSource = BasicDataSourceFactory.createDataSource(p);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  // 浠庤繛鎺ユ睜涓幏鍙栬繛鎺�
  public static synchronized Connection getConnection() throws SQLException {
    if (dataSource == null) {
      init();
    }
    Connection conn = null;
    if (dataSource != null) {
      conn = dataSource.getConnection();
    }
    return conn;
  }

  /**
   * 鎵цINSERT/UPDATE/DELETE SQL璇彞
   * 
   * @param sql SQL璇彞锛屽瓧绗︿覆绫诲瀷
   * @return 鎵ц缁撴灉锛宨nt绫诲瀷
   */
  // 鍥犱负娑夊強鍒版洿鏂版搷浣滄椂鎴戜滑涓�鑸兘闇�瑕佷紶鍏ュ弬鏁�,鎴戜滑涔熶笉鑳戒繚璇佹瘡涓猄QL璇彞
  // 涓弬鏁扮殑涓暟锛屽洜姝や娇鐢⊿tatement姣旇緝鍚堥��,灏嗗甫鏈夊弬鏁扮殑SQL璇彞鐩存帴浼犻�掕繃鏉�
  public static int executeUpdate(String sql) {
    int result = 0;
    try {
      s = getConnection().createStatement();
      result = s.executeUpdate(sql);
    } catch (SQLException e) {

      e.printStackTrace();
    }
    return result;
  }

  /**
   * 鎵цSELECT SQL璇彞
   * 
   * @param sql SQL璇彞锛屽瓧绗︿覆绫诲瀷
   * @return ResultSet缁撴灉闆�
   */
  public static ResultSet executeQuery(String sql) {

    try {
      s = getConnection().createStatement();
      rs = s.executeQuery(sql);
    } catch (SQLException e) {

      e.printStackTrace();
    }
    return rs;
  }

  /**
   * 鎵ц鍔ㄦ�丼QL璇彞
   * 
   * @param sql 鍚湁鍙傛暟鐨勫姩鎬丼QL璇彞銆�
   * @return 杩斿洖PreparedStatement瀵硅薄
   */
  public static PreparedStatement executePreparedStatement(String sql) {
    PreparedStatement ps = null;
    try {
      ps = getConnection().prepareStatement(sql);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return ps;
  }

  /**
   * 浜嬪姟鍥炴粴
   */
  public static void rollback() {
    try {
      getConnection().rollback();
    } catch (SQLException e) {

      e.printStackTrace();
    }
  }

  /**
   * 鍏抽棴鏁版嵁搴撹繛鎺ュ璞�
   */
  public static void close() {
    try {
      if (rs != null)
        rs.close();
      if (s != null)
        s.close();
      if (conn != null)
        conn.close();

    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
}
