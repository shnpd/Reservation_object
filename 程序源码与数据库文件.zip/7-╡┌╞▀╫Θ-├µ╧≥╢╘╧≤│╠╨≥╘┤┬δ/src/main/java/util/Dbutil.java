package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Dbutil {
  private static final String DATABASE_NAME = "order";
  /**
   * 澹版槑杩炴帴鏁版嵁搴撶殑淇℃伅锛屽鏁版嵁搴揢RL銆佺敤鎴峰悕鍙婂瘑鐮乗
   * 
   * @param DATABASE_NAME:鏁版嵁搴撳悕
   * @param USERNAME:mysql鐧婚檰鍚�
   * @param PASSWORD:mysql鐧婚檰瀵嗙爜
   */
  // database:javaweb_work
  private static final String URL = "jdbc:mysql://localhost:3306/" + DATABASE_NAME
      + "?useUnicode=true&characterEncoding=UTF-8";
  private static final String USERNAME = "root";
  private static final String PASSWORD = "shn001221";
  /**
   * 澹版槑JDBC鐩稿叧瀵硅薄
   */
  protected static Statement s = null;
  protected static Statement ps = null;
  protected static ResultSet rs = null;
  protected static Connection conn = null;

  /**
   * 鍒涘缓鏁版嵁搴撹繛鎺�
   * synchronized淇グ涓�涓柟娉曪紝琚慨楗扮殑鏂规硶绉颁负鍚屾鏂规硶锛屽叾浣滅敤鐨勮寖鍥存槸鏁翠釜鏂规硶锛屼綔鐢ㄧ殑瀵硅薄鏄皟鐢ㄨ繖涓柟娉曠殑瀵硅薄锛�
   * 
   * @return conn
   */
  public static synchronized Connection getConnection() {
    try {
      Class.forName("com.mysql.jdbc.Driver");
      conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return conn;
  }

  /**
   * 鎵цINSERT/UPDATE/DELETE SQL璇彞
   * 
   * @param sql SQL璇彞锛屽瓧绗︿覆绫诲瀷
   * @return 鎵ц缁撴灉锛宨nt绫诲瀷
   * @throws SQLException
   */
  public static int executeUpdate(String sql) throws SQLException {
    int count = 0;
    try {
      s = getConnection().createStatement();
      count = s.executeUpdate(sql);
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      s.close();
    }
    return count;
  }

  /**
   * 鎵цSELECT SQL璇彞
   * 
   * @param sql SQL璇彞锛屽瓧绗︿覆绫诲瀷
   * @return ResultSet缁撴灉闆�
   */
  public static ResultSet executeQuery(String sql) {

    try {
      s = getConnection().createStatement();
      rs = s.executeQuery(sql);
    } catch (SQLException e) {

      e.printStackTrace();
    }
    return rs;
  }

  /**
   * 鎵цSELECT SQL璇彞浣跨敤PreparedStatment
   * 
   * @param sql
   * @return
   */
  public static ResultSet executeQuerywithPrepare(String sql) {

    try {
      s = getConnection().prepareStatement(sql);
      rs = s.executeQuery(sql);
    } catch (SQLException e) {

      e.printStackTrace();
    }
    return rs;
  }

  /**
   * 鎵ц鍔ㄦ�丼QL璇彞
   * 
   * @param sql 鍚湁鍙傛暟鐨勫姩鎬丼QL璇彞銆�
   * @return 杩斿洖PreparedStatement瀵硅薄
   */
  public static PreparedStatement executePreparedStatement(String sql) {
    PreparedStatement ps = null;
    try {
      ps = getConnection().prepareStatement(sql);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return ps;
  }

  /**
   * 浜嬪姟鍥炴粴
   */
  public static void rollback() {
    try {
      getConnection().rollback();
    } catch (SQLException e) {

      e.printStackTrace();
    }

  }

  /**
   * 鍏抽棴鏁版嵁搴撹繛鎺ュ璞�
   */
  public static void close() {
    try {
      if (rs != null)
        rs.close();
      if (s != null)
        s.close();
      if (conn != null)
        conn.close();

    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  public static void main(String[] args) {
    /*
     * String sql =
     * "INSERT INTO tb_users(fd_username,fd_password,fd_usertype,fd_gender,fd_birthdate,fd_email) VALUES ('Wangli','aWeY92,zeP', "
     * + "'绠＄悊鍛�','濂�','1999-10-22','allen@henu.edu.cn')"; executeUpdate(sql);
     * close();
     */
    // 缂栧啓SQL璇彞
    String sql = "INSERT INTO tb_users(fd_username,fd_password,fd_usertype,fd_gender,fd_email,"
        + "fd_birthdate, fd_introduction,fd_hobby) VALUES (?,?,?,?,?,?,?,?)";

    // 鎵цSQL
    PreparedStatement ps = Dbutil.executePreparedStatement(sql);
    try {
      ps.setString(1, "username");
      ps.setString(2, "password");
      ps.setString(3, "1");
      ps.setString(4, "鐢�");
      ps.setString(5, "email");
      ps.setString(6, "birthdate");
      ps.setString(7, "introduction");
      ps.setString(8, "hobby");
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

    int result = 0;
    try {
      result = ps.executeUpdate();
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    try {
      ps.close();
    } catch (SQLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }
}
