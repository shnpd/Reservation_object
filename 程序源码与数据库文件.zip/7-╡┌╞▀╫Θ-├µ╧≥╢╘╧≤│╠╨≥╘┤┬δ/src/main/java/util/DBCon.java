package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBCon {
  static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/order?user=root&password=shn001221&useUnicode=true&characterEncoding=UTF-8&useSSL=true";
  static Connection conn = null;

  // �������ݿ�
  public static Connection getConnection() {
    try {
      Class.forName(JDBC_DRIVER);
      conn = DriverManager.getConnection(DB_URL);
      System.out.println("���ӳɹ�");
    } catch (Exception e) {
      e.printStackTrace();
    }
    return conn;
  }

  // �ر����ݿ�����
  public static void Close() {
    try {
      if (conn != null) {
        conn.close();
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

}
